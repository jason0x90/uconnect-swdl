precision mediump float;

void main() 
{
	gl_FragColor = vec4(mod(gl_FragCoord.x,16.0)/16.0,mod(gl_FragCoord.y,16.0)/16.0,mod(gl_FragCoord.z*100.0,16.0)/16.0,1);
}
