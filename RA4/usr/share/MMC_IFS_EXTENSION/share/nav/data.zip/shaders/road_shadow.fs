precision mediump float;

void main() 
{
	gl_FragColor = vec4(0, 0, 0, 0.125);
}
