precision mediump float;

uniform vec4 Ucolor;

void main() 
{
	gl_FragColor = Ucolor;
	gl_FragColor.a = 1.; 
}
