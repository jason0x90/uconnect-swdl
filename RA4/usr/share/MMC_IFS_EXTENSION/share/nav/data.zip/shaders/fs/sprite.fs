precision highp float;
varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;
void main()
{
  gl_FragColor = texture2D( texture, v_txCoor )*Ucolor;
  //gl_FragColor.r = v_txCoor.x;
  //gl_FragColor.a = 0.5;
}