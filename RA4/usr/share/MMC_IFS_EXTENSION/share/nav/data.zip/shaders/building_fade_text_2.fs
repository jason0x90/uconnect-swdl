precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;

void main()
{
	vec4 c = texture2D( texture, v_txCoor );
	gl_FragColor.rgb = c.rgb;
	gl_FragColor.a = c.a * 0.5;
}
