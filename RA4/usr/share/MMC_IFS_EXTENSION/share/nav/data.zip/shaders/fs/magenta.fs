precision mediump float;

void main() 
{
	gl_FragColor = vec4(1.,0.,1.,1.);
}
