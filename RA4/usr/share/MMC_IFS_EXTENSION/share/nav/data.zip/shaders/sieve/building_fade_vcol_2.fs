precision mediump float;

varying vec4 v_color;

void main() 
{
	gl_FragColor = v_color;
	gl_FragColor.a =  1.;

	if( floor(mod(gl_FragCoord.x, 2.)) < 0.9 &&
	    floor(mod(gl_FragCoord.y+1., 2.)) < 0.9 )
		gl_FragColor.a = 0.;

}
